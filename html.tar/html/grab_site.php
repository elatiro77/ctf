<?php

$site_name = $_GET['site'];

$site_content=file_get_contents($site_name);

if ($site_name=="http://169.254.169.254/latest/meta-data/" && $site_content=='') {
  print "FLAG1-YVaWgKzcovq13FwTvrwb";
  echo "<p>";
  echo "<font color=green size=4 >"."You Have Entered:"."</font>";
  echo "<font color=red size=6 face=verdana>".$site_name."</font>";
  echo"</p";
} else {
  print $site_content;
  echo "<p>";
  echo "<font color=green size=4 >"."You Have Entered:"."</font>";
  echo "<font color=red size=6 face=verdana>".$site_name."</font>";
  echo"</p";
} 


?>

<?php

$site_name = $_GET['site'];

$site_content=file_get_contents($site_name);

if (strpos($site_name,'http://169.254.169.254') !== false && $site_content=='') {
  print "FLAG1-YVaWgKzcovq13FwTvrwb";
} elseif(strpos($site_name,'http://169.254.169.254') !== false && $site_content!==''){
        print $site_content;
}

?>


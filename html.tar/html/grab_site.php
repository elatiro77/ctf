<?php

$site_name = $_GET['site'];

$site_content=file_get_contents($site_name);

if ($site_name=="http://169.254.169.254/latest/meta-data/" && $site_content=='') {
  print "FLAG1-YVaWgKzcovq13FwTvrwb";
} else {
  print $site_content;
}


?>


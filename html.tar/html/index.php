<!DOCTYPE html>
<html>
<head><title>Synonyms</title>
<link rel="stylesheet" href="site_style.css">

</head>
<body>
<div id="cover">
  <form method="get" action="">
    <div class="tb">
      <div class="td"><input type="text" name="site" placeholder="Search" required></div>
      <div class="td" id="s-cover">
        <button type="submit">
          <div id="s-circle"></div>
          <span></span>
        </button>>
      </div>
    </div>
  </form>
</div>
<div>
<?php include 'grab_site.php'; ?>
</div>
</body>
</html>


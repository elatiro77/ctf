<!DOCTYPE html>
<html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head><title>Grab Site</title>
<link rel="stylesheet" href="site_style.css">

</head>
<body>

<div align="center">Enter URL to grab its contents:</div>
<div class="wrap">
<form class="search" method="get" action="">
 <input type="url" name="site" class="searchTerm" placeholder="http://example.com" required>
 <button type="submit" class="searchButton" placeholder="search"> <i class="fa fa-search"></i></button>
 <button type="reset" class="clearButton" placeholder="reset">CLEAR</button>
</form>
</div>
<div align="bottom">
<table align="bottom">
<tr><td><?php include 'grab_site.php'; ?></td></tr>
</table>
<div>



</body>
</html>

